import React from 'react';
const NewProduct = () => {
    return ( <>
    
    <h1>

        hello
    </h1>
    
    </> );
}
 
export default NewProduct;